// dataProviders/index.js - Provider factory
const config = require('../config');

class DataProviderFactory {
  static createProvider() {
    const dataSourceType = config.getDataSourceType();
    
    switch (dataSourceType) {
      case 'supabase':
        const SupabaseProvider = require('./supabaseProvider');
        return new SupabaseProvider();
      
      case 'textfiles':
        const TextFileProvider = require('./textFileProvider');
        return new TextFileProvider();
      
      default:
        throw new Error(`Unknown data source type: ${dataSourceType}`);
    }
  }
}

// Base provider interface - all providers must implement these methods
class DataProvider {
  // Authentication methods
  async login(email, password) {
    throw new Error('login() must be implemented');
  }

  async register(email, password) {
    throw new Error('register() must be implemented');
  }

  isAuthRequired() {
    throw new Error('isAuthRequired() must be implemented');
  }

  // Data access methods
  async getTableData(tableName, userId) {
    throw new Error('getTableData() must be implemented');
  }

  async getRowById(tableName, id, userId) {
    throw new Error('getRowById() must be implemented');
  }

  async insertRow(tableName, data, userId) {
    throw new Error('insertRow() must be implemented');
  }

  async updateRow(tableName, id, data, userId) {
    throw new Error('updateRow() must be implemented');
  }

  async deleteRow(tableName, id, userId) {
    throw new Error('deleteRow() must be implemented');
  }

  async getLookupValues(tableName, fieldName) {
    throw new Error('getLookupValues() must be implemented');
  }

  // Discovery method
  async getAvailableTables() {
    throw new Error('getAvailableTables() must be implemented');
  }
}

module.exports = {
  DataProviderFactory,
  DataProvider
};