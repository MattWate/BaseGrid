// config.js - Configuration loader
const fs = require('fs');
const path = require('path');

class Config {
  constructor() {
    this.config = null;
    this.load();
  }

  load() {
    try {
      // Load config.json
      const configPath = path.join(__dirname, 'config.json');
      const configFile = fs.readFileSync(configPath, 'utf8');
      this.config = JSON.parse(configFile);

      // Override with environment variables if they exist
      if (process.env.DATA_SOURCE) {
        this.config.dataSource.type = process.env.DATA_SOURCE;
      }
      if (process.env.PORT) {
        this.config.server.port = parseInt(process.env.PORT);
      }
      if (process.env.SUPABASE_URL) {
        this.config.supabase.url = process.env.SUPABASE_URL;
      }
      if (process.env.SUPABASE_ANON_KEY) {
        this.config.supabase.anonKey = process.env.SUPABASE_ANON_KEY;
      }
      if (process.env.DATA_DIRECTORY) {
        this.config.textfiles.dataDirectory = process.env.DATA_DIRECTORY;
      }

      console.log(`Configuration loaded: Data source = ${this.config.dataSource.type}`);
    } catch (error) {
      console.error('Error loading configuration:', error);
      throw error;
    }
  }

  get(key) {
    const keys = key.split('.');
    let value = this.config;
    for (const k of keys) {
      value = value[k];
      if (value === undefined) {
        return null;
      }
    }
    return value;
  }

  getDataSourceType() {
    return this.config.dataSource.type;
  }

  getPort() {
    return this.config.server.port;
  }

  getSupabaseConfig() {
    return this.config.supabase;
  }

  getTextFilesConfig() {
    return this.config.textfiles;
  }

  getAuthConfig() {
    return this.config.auth;
  }
}

// Export singleton instance
module.exports = new Config();